package ar.edu.uade.test;


import ar.edu.uade.controllers.ReclamoController;
import ar.edu.uade.modelo.Reclamo;
import ar.edu.uade.repositories.ReclamoRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(ReclamoController.class)
public class ReclamoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ReclamoRepository reclamoRepository;

    @Test
    public void getAllReclamos_returnsOk() throws Exception {
        Mockito.when(reclamoRepository.findAll()).thenReturn(Collections.emptyList());
        mockMvc.perform(get("/api/reclamos"))
                .andExpect(status().isOk());
    }
}
