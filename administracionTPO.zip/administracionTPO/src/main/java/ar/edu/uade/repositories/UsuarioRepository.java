package ar.edu.uade.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.uade.modelo.Persona;

public interface UsuarioRepository extends JpaRepository<Persona, Long> {
    Persona findByUsername(String username);
}	