package ar.edu.uade.daos;
import java.util.*;

import ar.edu.uade.modelo.Reclamo;

public interface ReclamoDAO {
    Reclamo crearReclamo(Reclamo reclamo);
    Reclamo obtenerReclamoPorId(Long id);
    List<Reclamo> obtenerReclamosPorUsuario(Long usuarioId);
    List<Reclamo> obtenerReclamosPorEdificio(Long edificioId);
    Reclamo actualizarReclamo(Reclamo reclamo);
    void eliminarReclamo(Long id);
}
