package ar.edu.uade.daos;
import java.util.*;

import ar.edu.uade.modelo.Edificio;

public interface EdificioDAO {
    List<Edificio> obtenerTodosLosEdificios();
    Edificio obtenerEdificioPorId(Long id);
    Edificio crearEdificio(Edificio edificio);
    Edificio actualizarEdificio(Edificio edificio);
    void eliminarEdificio(Long id);
}