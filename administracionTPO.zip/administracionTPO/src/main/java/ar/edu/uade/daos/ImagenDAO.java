package ar.edu.uade.daos;
import java.util.*;

import ar.edu.uade.modelo.Imagen;

public interface ImagenDAO {
	
    Imagen crearFoto(Imagen foto);
    List<Imagen> obtenerFotosPorReclamo(Long reclamoId);
}