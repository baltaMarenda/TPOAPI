package ar.edu.uade.controllers;

import ar.edu.uade.services.ImagenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/api/imagenes")
public class ImagenController {

    @Autowired
    private ImagenService imagenService;

    @PostMapping("/upload")
    public String uploadImage(@RequestParam("file") MultipartFile file) {
        try {
            return imagenService.guardarImagen(file);
        } catch (IOException e) {
            throw new RuntimeException("Error al subir la imagen", e);
        }
    }
}