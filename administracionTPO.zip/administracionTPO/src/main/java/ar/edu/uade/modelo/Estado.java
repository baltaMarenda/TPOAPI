package ar.edu.uade.modelo;

public enum Estado {
    NUEVO,
    ABIERTO,
    EN_PROCESO,
    DESESTIMADO,
    ANULADO,
    TERMINADO;
}
