package ar.edu.uade.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.uade.modelo.Reclamo;
import java.util.List;

public interface ReclamoRepository extends JpaRepository<Reclamo, Long> {
    List<Reclamo> findByEdificioId(Long edificioId);
    List<Reclamo> findByUsuarioId(Long usuarioId);
}
