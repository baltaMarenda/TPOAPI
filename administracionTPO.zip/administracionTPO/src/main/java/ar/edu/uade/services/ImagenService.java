package ar.edu.uade.services;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class ImagenService {

    private final String uploadDir = "/ruta/a/imagenes";

    public String guardarImagen(MultipartFile file) throws IOException {
        String filePath = uploadDir + File.separator + file.getOriginalFilename();
        Files.copy(file.getInputStream(), Paths.get(filePath));
        return filePath;
    }
}