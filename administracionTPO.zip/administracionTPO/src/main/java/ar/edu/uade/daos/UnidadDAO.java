package ar.edu.uade.daos;
import java.util.*;

import ar.edu.uade.modelo.Unidad;

public interface UnidadDAO {
    List<Unidad> obtenerUnidadesPorEdificio(Long edificioId);
    Unidad obtenerUnidadPorId(Long id);
    Unidad crearUnidad(Unidad unidad);
    Unidad actualizarUnidad(Unidad unidad);
    void eliminarUnidad(Long id);
}
