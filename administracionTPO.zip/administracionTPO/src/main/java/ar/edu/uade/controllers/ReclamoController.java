package ar.edu.uade.controllers;

import ar.edu.uade.modelo.Reclamo;
import ar.edu.uade.repositories.ReclamoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reclamos")
public class ReclamoController {

    @Autowired
    private ReclamoRepository reclamoRepository;

    @GetMapping
    public List<Reclamo> getAllReclamos() {
        return reclamoRepository.findAll();
    }

    @GetMapping("/usuario/{usuarioId}")
    public List<Reclamo> getReclamosByUsuario(@PathVariable Long usuarioId) {
        return reclamoRepository.findByUsuarioId(usuarioId);
    }

    @PostMapping
    public Reclamo createReclamo(@RequestBody Reclamo reclamo) {
        return reclamoRepository.save(reclamo);
    }

    @PutMapping("/{id}")
    public Reclamo updateReclamo(@PathVariable Long id, @RequestBody Reclamo reclamoDetails) {
        Reclamo reclamo = reclamoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Reclamo no encontrado"));

        reclamo.setDescripcion(reclamoDetails.getDescripcion());
        reclamo.setEstado(reclamoDetails.getEstado());

        return reclamoRepository.save(reclamo);
    }
}