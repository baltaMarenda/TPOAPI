package ar.edu.uade.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import ar.edu.uade.modelo.Unidad;

public interface UnidadRepository extends JpaRepository<Unidad, Long> {
}
